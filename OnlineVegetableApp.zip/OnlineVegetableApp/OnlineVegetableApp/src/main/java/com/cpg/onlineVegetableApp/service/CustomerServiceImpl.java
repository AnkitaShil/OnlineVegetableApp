package com.cpg.onlineVegetableApp.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cpg.onlineVegetableApp.dao.ICustomerRepository;

import com.cpg.onlineVegetableApp.entities.Customer;

@Service
@Transactional
public class CustomerServiceImpl implements ICustomerService{
	
	@Autowired
	ICustomerRepository repository;

	@Override
	public Customer addCustomer(Customer customer) {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
	try {
		Customer customer2=repository.save(customer);
		return (customer2);
		}
		catch(Exception e)
		{
		throw e;
		}
	
	}

	@Override
	public Customer updateCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Customer removeCustomer(Customer customer) {
		// TODO Auto-generated method stub
		
		try
		{
			int id=customer.getCustomerId();
			Optional<Customer> optionalcustomer=repository.findById(id);
			Customer customer2=null;
			if(optionalcustomer.isPresent())
			{
				customer=optionalcustomer.get();
				repository.deleteById(id);
				return customer2;
			}
			else {
			return customer2;
			}
		}
		catch(Exception e)
		{
			throw e;
		}
	}

	@Override
	public Customer viewCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Customer> viewCustomerList(String location) {
		// TODO Auto-generated method stub
		return null;
	}

}
