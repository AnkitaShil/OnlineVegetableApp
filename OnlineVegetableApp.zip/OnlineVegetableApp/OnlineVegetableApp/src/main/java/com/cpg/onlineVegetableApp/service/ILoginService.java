package com.cpg.onlineVegetableApp.service;

import com.cpg.onlineVegetableApp.entities.User;

public interface ILoginService {
	 public User validateUser(User user);
	 public User logout(User user);
}
