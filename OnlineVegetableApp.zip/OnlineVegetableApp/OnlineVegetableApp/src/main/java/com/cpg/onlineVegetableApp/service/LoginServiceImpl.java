package com.cpg.onlineVegetableApp.service;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.cpg.onlineVegetableApp.entities.User;

@Service
@Transactional
public class LoginServiceImpl implements ILoginService{

	@Override
	public User validateUser(User user) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public User logout(User user) {
		// TODO Auto-generated method stub
		return null;
	}

}
