package com.cpg.onlineVegetableApp.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cpg.onlineVegetableApp.dao.ICartRepository;

import com.cpg.onlineVegetableApp.entities.Cart;
import com.cpg.onlineVegetableApp.entities.VegetableDTO;


@Service
@Transactional
public class CartServiceImpl implements ICartService{
	
	@Autowired
	ICartRepository repository;

	@Override
	public VegetableDTO addToCart(VegetableDTO item) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Cart removeVegetable(int vegId) {
		// TODO Auto-generated method stub
		try
		{
			
			Optional<Cart> optionalcart=repository.findById(vegId);
			Cart cart2=null;
			if(optionalcart.isPresent())
			{
				cart2=optionalcart.get();
				repository.deleteById(vegId);
				return cart2;
			}
			else {
			return cart2;
			}
		}
		catch(Exception e)
		{
			throw e;
		}
	
	}

	@Override
	public Cart increaseVegQuantity(int vegId, int quantity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Cart decreseVegQuantity(int vegId, int quantity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<VegetableDTO> viewAllItems(Cart cart) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Cart removeAllItems(Cart cart) {
		// TODO Auto-generated method stub
		return null;
	}



}
